
<?php echo $__env->make('components.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>
<!-- Interests-->
<section class="resume-section" id="interests">
    <div class="resume-section-content">
        <h2 class="mb-5 text-white">Interests</h2>
        <p class="text-align-justify text-white"> Complicated technologies, such as robotics and AI, excite me the most. In my free time, I enjoy going for long drives on my bike. Additionally, I have a penchant for watching thriller movies. Playing outdoor games helps me unwind and remain stress-free. Moreover, I absolutely love listening to songs whenever I have the opportunity.</p>
    </div>
</section>
<hr class="text-primary">
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\OstadAssignment\module9\assignment9\resources\views/pages/interestsPage.blade.php ENDPATH**/ ?>