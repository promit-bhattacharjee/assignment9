
<?php echo $__env->make('components.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>
 <!-- Education -->
 <hr class="text-primary">
 <section class="resume-section mt-0 " id="education">
     <div class="resume-section-content">
         <h2 class="mb-5 text-white">Education</h2>
         <div class="d-flex flex-column border-2 border-primary flex-md-row justify-content-between mb-5">
             <div class=" text-white">
                 <h3 class="mb-0 text-primary">Leading University</h3>
                 <div class="subheading text-white">Bachelor of Science in</div>
                 <div>Computer Science and Engineering</div>
                 <p>Grade: B</p>
             </div>
             <div class="flex-shrink-0"><span class="text-primary">September 2019 - Present</span></div>
         </div>
         <div class="resume-section-content">
             <div class="d-flex flex-column flex-md-row justify-content-between mb-5">
                 <div class="flex-grow-1 text-white">
                     <h3 class="mb-0 text-primary">Moulvibazar Govt College</h3>
                     <div class="text-white">Higher Secondary Certificate</div>
                     <div></div>
                     <p>Grade: A-</p>
                 </div>
                 <div class="flex-shrink-0"><span class="text-primary">July 2017 - April 2019</span></div>
             </div>
         <div class="resume-section-content">
             <div class="d-flex flex-column flex-md-row justify-content-between mb-5">
                 <div class="flex-grow-1 text-white">
                     <h3 class="mb-0 text-primary">Nayabazar K.C High School and College</h3>
                     <div class="text-white">Higher Secondary Certificate</div>
                     <div></div>
                     <p>Grade: A</p>
                 </div>
                 <div class="flex-shrink-0"><span class="text-primary">January 2015 - February 2017</span></div>
             </div>

 </section>
 <hr class="text-primary">
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\OstadAssignment\module9\assignment9\resources\views/pages/educationPage.blade.php ENDPATH**/ ?>