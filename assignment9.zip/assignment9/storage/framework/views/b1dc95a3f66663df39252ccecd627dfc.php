
<?php echo $__env->make('components.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Awards-->
    <section class="resume-section" id="awards">
        <div class="resume-section-content">
            <h2 class="mb-5 text-white">Awards & Certifications</h2>
            <ul class="fa-ul mb-0">

                <li>
                    <span class="fa-li"><i class="fas fa-trophy text-warning"></i></span><span class="text-white">                    Programming hero web Development course
                    </span>
                </li>
            </ul>
        </div>
    </section>
    <hr class="bg-primary">
<hr class="text-primary">
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\OstadAssignment\module9\assignment9\resources\views/pages/awardsPage.blade.php ENDPATH**/ ?>