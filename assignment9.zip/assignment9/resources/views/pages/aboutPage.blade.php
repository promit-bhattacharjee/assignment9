 @extends('layout.app')
 @include('components.navbar')
 @section('content')
<hr class="bg-primary"> 
<section class="resume-section">
    <div class="about-me row">
        <div class="My-skills col-sm-12 col-md-12 col-xs-12 col-lg-6 col-xl-6 col-xxl-6 ">
            <div class="resume-section-content mb-sm-5 mb-md-5 mb-5 mb-lg-0 mb-xl-0 mb-xxl-0">
            <div id="skills"> <!-- MySkill -->
                <h2 class="mb-5 text-white">My Skills</h2>
                <!-- Programming Language -->
                <div class="subheading text-primary mb-3"  >Programming Languages</div>
                <ul class="list-inline container">
                    <li class="list-inline-item mt-3 mb-sm-3 mb-md-3 mb-3 mb-lg-0 mb-xl-0 mb-xxl-0"><span class="text-dark bg-white m-1 p-2 rounded-1">PHP</span>
                    </li>
                    <li class="list-inline-item mt-3 mb-sm-3 mb-md-3 mb-3 "><span class="text-dark bg-white m-1 p-2 rounded-1">Java
                            Script</span></li>
                    <li class="list-inline-item mt-3 mt-3 mb-sm-3 mb-md-3 mb-3"><span class="text-dark bg-white m-1 p-2 rounded-1">Java</span>
                    </li>
                    <li class="list-inline-item mt-3 mt-3 mb-sm-3 mb-md-3 mb-3"><span class="text-dark bg-white m-1 p-2 rounded-1">Dart</span>
                    </li>
                    <li class="list-inline-item mt-3 mt-3 mb-sm-3 mb-md-3 mb-3"><span class="text-dark bg-white m-1 p-2 rounded-1">C
                            programming</span></li>
                </ul>
                <!-- MarkUP And StyleSheet -->
                <div class="subheading mb-3 text-primary">Markup Language & Stylesheet Language</div>
                <ul class="list-inline container">
                    <li class="list-inline-item mt-3 mb-sm-3 mb-md-3 mb-3"><span class="text-dark bg-white m-1 p-2 rounded-1">HTML 5</span>
                    </li>
                    <li class="list-inline-item mt-3 mb-sm-3 mb-md-3 mb-3"><span class="text-dark bg-white m-1 p-2 rounded-1">CSS 3</span>
                    </li>
                </ul>
                <!-- FrameWork -->
                <div class="subheading mb-3 text-primary ">Framework</div>
                <ul class="list-inline container mt-3 mb-sm-3 mb-md-3 mb-3">
                    <li class="list-inline-item mt-3 mb-sm-3 mb-md-3 mb-3"><span class="text-dark bg-white m-1 p-2 rounded-1">Flutter</span>
                    </li>
                    <li class="list-inline-item mt-3 mb-sm-3 mb-md-3 mb-3"><span class="text-dark bg-white m-1 p-2 rounded-1">Swing</span>
                    </li>
                    <li class="list-inline-item mt-3 mb-sm-3 mb-md-3 mb-3"><span class="text-dark bg-white m-1 p-2 rounded-1">Bootstrap</span>
                    </li>
                </ul>
                <!-- DataBase -->
                <div class=" subheading mb-3 text-primary">Database</div>
                <ul class="container list-inline">
                    <li class="list-inline-item mt-3 mb-sm-3 mb-md-3 mb-3"><span class="text-dark bg-white m-1 p-2 rounded-1">Firebase</span>
                    </li>
                    <li class="list-inline-item mt-3 mb-sm-3 mb-md-3 mb-3"><span class="text-dark bg-white m-1 p-2 rounded-1">MySQL
                            database</span></li>
                </ul>
                <!-- TOOLS -->
                <div class="subheading text-primary mb-3">Tools</div>
                <ul class="list-inline container">
                    <li class="list-inline-item mt-3 mt-3 mb-sm-3 mb-md-3 mb-3"><span class="text-dark bg-white m-1 p-2  rounded-1">Visual
                            StudioCode</span></li>
                    <li class="list-inline-item mt-3 mt-3 mb-sm-3 mb-md-3 mb-3"><span
                            class="text-dark bg-white m-1 p-2 rounded-1">Brackets</span></li>
                    <li class="list-inline-item mt-3 mt-3 mb-sm-3 mb-md-3 mb-3"><span class="text-dark bg-white m-1 p-2  rounded-1">Git</span>
                    </li>
                    <li class="list-inline-item mt-3 mt-3 mb-sm-3 mb-md-3 mb-3"><span class="text-dark bg-white m-1 p-2  rounded-1">Andriod
                            Studio</span></li>
                    <li class="list-inline-item mt-3 mt-3 mb-sm-3 mb-md-3 mb-3"><span class="text-dark bg-white m-1 p-2  rounded-1">Firebase
                            cli</span></li>
                    <li class="list-inline-item mt-3 mt-3 mb-sm-3 mb-md-3 mb-3"><span class="text-dark bg-white m-1 p-2  rounded-1">Code
                            Blocks</span></li>
                    <li class="list-inline-item mt-3 mt-3 mb-sm-3 mb-md-3 mb-3"><span class="text-dark bg-white m-1 p-2  rounded-1">Eclipse
                            IDE</span></li>
                    <li class="list-inline-item mt-3 mt-3 mb-sm-3 mb-md-3 mb-3"><span class="text-dark bg-white m-1 p-2 rounded-1">
                            Netlify</span></li>
                    <li class="list-inline-item mt-3 mt-3 mb-sm-3 mb-md-3 mb-3"><span class="text-dark bg-white m-1 p-2 rounded-1">
                            IntelliJ</span></li>
                </ul>
                <!-- Fimiliar -->
                <div class="subheading mb-3 text-primary">Familiar</div>
                <ul class="container list-inline">
                    <li class="list-inline-item mt-3 mb-sm-3 mb-md-3 mb-3"><span class="text-dark bg-white m-1 p-2 rounded-1">React</span>
                    </li> 
                    <li class="list-inline-item mt-3 mb-sm-3 mb-md-3 mb-3"><span class="text-dark bg-white m-1 p-2 rounded-1">Tailwind</span>
                    </li> 
                    <li class="list-inline-item mt-3 mb-sm-3 mb-md-3 mb-3"><span class="text-dark bg-white m-1 p-2 rounded-1">MongoDB</span>
                    </li> 
                    <li class="list-inline-item mt-3 mb-sm-3 mb-md-3 mb-3"><span class="text-dark bg-white m-1 p-2 rounded-1">C++</span></li>

                </ul></div>   
            </div>
        </div>
        <div class="resume-section mt-sm-5 mt-md-5 mt-5 mt-lg-0 mt-xl-0 mt-xxl-0 contact-info col col-sm-12 col-md-12 col-xs-12 col-lg-6 col-xl-6 col-xxl-6" id="about">
            <div class="resume-section-content" >
                <!-- About -->
            <h2 class="mb-5 text-white">About</h2>
            <div class="subheading mb-3 text-primary">Email</div>
            <ul class="container list-inline">
                <li class="list-inline-item">
                    <a class="text-decoration-none text-white" href="mailto:promitBhattacharjee21@gmail.com">
                        <span class="m-1 p-2 rounded-1"> promitbhattacharjee21@gmail.com</span></a>
            </ul>
            <div class="subheading mb-3 text-primary">Mobile Number</div>
            <ul class="container list-inline">
                <li class="list-inline-item">
                    <a class="text-decoration-none text-white" href="tel:+8801798142951">
                        <span class="m-1 p-2 rounded-1">+8801798142951</span></a>
            </ul>
            <div class="subheading mb-3 text-primary">Date of Birth</div>
            <ul class="container list-inline">
                <li class="list-inline-item">
                    <span class="m-1 p-2 rounded-1 text-white"> 1 January 2000
                    </span>
            </ul>
            <div class="subheading mb-3 text-primary">City</div>
            <ul class="container list-inline">
                <li class="list-inline-item">
                    <span class="m-1 p-2 rounded-1 text-white">Sylhet, Bangladesh
                    </span>
            </ul>
            <div class="subheading mb-3 text-primary">Degree:</div>
            <ul class="container list-inline">
                <li class="list-inline-item">
                    <span class="rounded-1 text-white text-align-justify">B.Sc in Computer Science and Engineering
                    </span>
            </ul>
            </div>
        </div>
    </div>
</section>
<hr class="bg-primary">
@endsection