@extends('layout.app')
@include('components.navbar')
@section('content')
    <!-- Awards-->
    <section class="resume-section" id="awards">
        <div class="resume-section-content">
            <h2 class="mb-5 text-white">Awards & Certifications</h2>
            <ul class="fa-ul mb-0">

                <li>
                    <span class="fa-li"><i class="fas fa-trophy text-warning"></i></span><span class="text-white">                    Programming hero web Development course
                    </span>
                </li>
            </ul>
        </div>
    </section>
    <hr class="bg-primary">
<hr class="text-primary">
 @endsection